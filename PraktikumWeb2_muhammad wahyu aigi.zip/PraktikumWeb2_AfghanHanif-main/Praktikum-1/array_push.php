<!DOCTYPE html>
<html lang="en">

<body>

    <?php
    $team = ["Afghan", "Alip", "Ilyash", "Tirta"];
    array_push($team, "Fendy");
    foreach ($team as $orang) {
        echo $orang . '<br/>';
    }
    ?>

</body>

</html>