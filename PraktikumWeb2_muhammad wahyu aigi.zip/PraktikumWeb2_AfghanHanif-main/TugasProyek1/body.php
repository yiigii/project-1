            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="col-sm-12" style="text-align: center; margin-top: 20%;">
                        <h1 class="m-0" style="font-family: poppins !important;">Selamat Datang di Admin Tugas Kuliah</h1>
                        <p style="font-family: poppins !important; margin-top: 10px;">Afghan Hanif Adiyat, Sistem Informasi 17</p>
                    </div><!-- /.col -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->