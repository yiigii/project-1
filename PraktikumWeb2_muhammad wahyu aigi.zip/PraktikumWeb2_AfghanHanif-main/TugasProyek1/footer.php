<footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="https://adminlte.io">Afghan Hanif Adiyat</a>.</strong>
    Pemrograman Web STT Terpadu Nurul Fikri.
</footer>